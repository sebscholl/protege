# Tools

Extension Surface: Yes

Tool extensions expose callable capabilities to the inference harness.

Tool contracts should stay stable and explicitly documented per extension.

## Tool Structure

Each tool must be implemented as:

1. `extensions/tools/{tool-name}/index.ts` or `extensions/tools/{tool-name}/index.js`
2. `extensions/tools/{tool-name}/README.md`

Entry point resolution order is `index.js` first, then `index.ts`.

Distribution guidance:

1. Local/private development: TypeScript entrypoints are fine.
2. Shared/distributed extensions: prefer shipping `index.js` for runtime portability.

## Isolation Boundary

1. Tool-specific request/response types must live inside the tool directory.
2. Tool-specific validation and mapping logic must live inside the tool directory.
3. Core engine code may only depend on generic tool contracts (`name`, `description`, `inputSchema`, `execute`) and generic runtime invocation.
4. If logic only applies to one tool, it belongs in that tool's directory.

## Current Tools

1. `shell`: Executes non-interactive shell commands through `shell.exec`.
2. `glob`: Finds files by glob pattern through `file.glob`.
3. `search`: Finds text matches by query through `file.search`.
4. `read-file`: Reads full UTF-8 file content through `read_file`.
5. `write-file`: Creates or overwrites UTF-8 file content through `write_file`.
6. `edit-file`: Applies literal text replacement edits through `edit_file`.
7. `send-email`: Sends outbound email via generic runtime action invocation.
8. `web-fetch`: Fetches one HTTP(S) URL through `web_fetch`.
9. `web-search`: Searches the web through `web_search` using config-selected providers.

Each tool lives in its own directory with `index.ts` and `README.md`. Optional static assets/config files are allowed when needed, but config defaults should live in tool code and overrides belong in `extensions/extensions.json`.

## Tool Config Options

Tool-specific configuration options are documented in each tool README.

Current configurable first-party tool:

1. `web-search`:
   1. `provider`: `perplexity | tavily`
   2. `defaultMaxResults`: positive integer
   3. `providers.{name}.apiKeyEnv`: env var key
   4. `providers.{name}.baseUrl`: optional base URL override

Tools with no runtime config options (v1):

1. `shell`
2. `glob`
3. `search`
4. `read-file`
5. `write-file`
6. `edit-file`
7. `send-email`
8. `web-fetch`

## Tool Development Workflow

1. Create directory:
   - `extensions/tools/{tool-name}/`
2. Add files:
   - `index.ts` (required)
   - `README.md` (required)
   - `config.json` (optional static defaults; prefer code defaults in `index.ts`)
3. Export one tool definition from `index.ts` with:
   - `name`
   - `description`
   - `inputSchema`
   - `execute({ input, context })`
4. Keep tool-specific types/validation/mapping inside the tool directory.
5. Register tool in `extensions/extensions.json`:
   - string form: `"tool-name"`
   - object form: `{ "name": "tool-name", "config": { ... } }`
6. Add tests:
   - tool tests under `tests/extensions/tools/{tool-name}/index.test.ts`
   - runtime/registry tests only for generic behavior
7. Validate:
   - `npm run lint`
   - `npm run typecheck`
   - `npm run test`
